import {setting,prepareWorkspace,exclusive,readVerifiedFile,writeNew} from './storage.js';
import {listCases,createCase,loadState,recover,append,casePath,saveBookmark} from './repository.js';
import {uuid,localTime,ENTITY_TYPES,normalize,assertWebTab,hostPattern,sha256,matchesDomain,recordUrls,citation,removeLegacyCaptureFilters} from './domain.js';
import {capture,selected,inject,broadcastAnnotations,saveAnnotation,saveEntity,updateAnnotation,verifyArtifact,exportCase,convertScreenshotToPdf} from './service.js';
import {t} from './i18n.js';
import {initControls,setActionLabel} from './icons.js';
import {exportSession} from './session-recorder.js';
import {archivedText,compareText} from './compare.js';
import {isSessionVisit} from './visits.js';
const $=id=>document.getElementById(id);
const {refreshTooltip,hideTooltip}=initControls();
let root=null,workspace=null,cases=[],activeCase=null,state={captures:{},annotations:{},entities:{},refs:{},audit:[]},tab=null,view='captures',page=0,busy=false,controller=null,pending=null,selectedId=null,viewerUrl=null,dialogSaving=false;
let preferences={theme:'system',paused:false,hiddenAnnotationDomains:[],maxBytes:64*1024*1024,annotations:true,screenshotStorage:'compact'};
const statuses={};
const sessionId=uuid();
const filterIds=['search','type-filter','status-filter','annotation-type-filter','domain-filter','date-filter','current-page-only','visits-only'];
const viewFilters={};
function resetFilters(){for(const id of filterIds){const input=$(id);if(input.type==='checkbox')input.checked=false;else input.value='';}page=0;renderList();}
function focusSearch(){if(!activeCase)return;$('details').hidden=true;selectedId=null;renderList();$('search').focus();$('search').select();}
function switchView(next){
  if(next===view){$('details').hidden=true;selectedId=null;renderList();return;}
  viewFilters[view]=Object.fromEntries(filterIds.map(id=>[id,$(id).type==='checkbox'?$(id).checked:$(id).value]));
  view=next;page=0;selectedId=null;$('details').hidden=true;
  for(const id of filterIds){const input=$(id),value=viewFilters[view]?.[id];if(input.type==='checkbox')input.checked=value ?? false;else input.value=value ?? '';}
  document.querySelectorAll('[data-view]').forEach(b=>{if(b.dataset.view===view)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});renderList();
}
let syncRevision=0,lastDeleted=null,sourceRevision=0,sourceTimer;
let initializing=true,connecting=false,caseSaving=false,folderPermission='prompt',folderLabel='';
let caseDestination=null,casePicking=false;
let bookmarkOperation=false;
let comparison=null,comparing=false,comparisonRevision=0;
let navigationState=null,recorderBusy=false,ownWindowId=null,sessionRefreshTimer;
const navigationNames={session_started:'Session started',session_stopped:'Session stopped',tab_snapshot:'Initial page',navigation:'Page visited',history_state:'Page visited',fragment:'Page anchor (legacy)',tab_entered:'Page entered this window',tab_left:'Tab left',tab_activated:'Tab visited',page_title:'Page title (legacy)',link_target:'Linked tab'};
function selectedSessionId(){return navigationState?.case_id===activeCase && navigationState.workspace_id===workspace?.workspace_id?navigationState.session_id:[...state.audit].reverse().find(e=>e.action==='navigation_recorded')?.details.session_id;}
function renderSession(){
  const ready=!!(root && workspace && activeCase),active=['starting','recording','stopping'].includes(navigationState?.status),pendingCount=navigationState?.pending?.length || 0,id=selectedSessionId();
  $('session-section').hidden=!ready && !active && !pendingCount;
  $('session-start').disabled=!ready || preferences.paused || initializing || connecting || caseSaving || busy || recorderBusy || active || pendingCount>0;
  $('session-stop').disabled=recorderBusy || navigationState?.status!=='recording';
  $('session-start').hidden=active || pendingCount>0;
  $('session-stop').hidden=!active;
  $('session-section').dataset.error=String(!!navigationState?.error);
  $('session-section').dataset.recording=String(active);
  $('session-journal').disabled=!id || recorderBusy;
  $('session-export').disabled=!id || recorderBusy || (id===navigationState?.session_id && (active || pendingCount>0));
  $('session-retry').hidden=!pendingCount || navigationState?.status!=='save_error';$('session-retry').disabled=recorderBusy;
  const scope=navigationState?.window_id===ownWindowId?'this window':'another window';
  const belongsHere=navigationState?.case_id===activeCase && navigationState?.workspace_id===workspace?.workspace_id,shown=active || pendingCount || belongsHere?navigationState:null;
  $('session-state').textContent=recorderBusy?'Updating session…':!shown?'Off · URLs and titles from this window only':`${active?'Recording '+scope:'Stopped'} · ${shown.case_label} · ${shown.saved} events saved${pendingCount?' · '+pendingCount+' pending':''}${shown.error?' · '+shown.error:''}`;
}
async function sessionCommand(type,extra={}){
  recorderBusy=true;renderSession();
  try{const result=await chrome.runtime.sendMessage({type,...extra});if(result?.error)throw new Error(result.error);navigationState=result.state;return result.state;}finally{recorderBusy=false;renderSession();}
}
function updateSetup(){
  const folderReady=!!(root && workspace),ready=folderReady && !!activeCase,locked=initializing || connecting || caseSaving,needsAccess=folderPermission!=='granted';
  document.body.dataset.ready=String(ready);document.body.dataset.needsAccess=String(needsAccess);
  $('collection').hidden=!ready;
  $('setup-progress').hidden=ready && !locked && !needsAccess;
  const step=folderReady && !needsAccess?1:0;
  ['step-folder','step-case','step-capture'].forEach((id,index)=>{const node=$(id);node.dataset.complete=String(!needsAccess && (index<step || ready));if(index===(ready && !needsAccess?2:step))node.setAttribute('aria-current','step');else node.removeAttribute('aria-current');});
  $('setup-next').textContent=initializing?'Checking your workspace…':connecting?'Connecting the folder and checking saved cases…':caseSaving?'Creating the case and verifying files…':!root?'Step 1 of 3 · Choose a folder for your files.':!folderReady || needsAccess?'Step 1 of 3 · Restore folder access or choose another folder.':'Step 2 of 3 · Create a case to organize your materials.';
  $('workspace-hint').textContent=root && needsAccess?'Restore access for the previous case, or choose New case with another destination.':ready?`Ready · ${cases.find(c=>c.case_id===activeCase)?.title || 'Active case'}. Captures and notes will be saved here.`:folderReady?'Your folder is connected. Create a case to continue.':'Choose a destination folder in New case, or connect a workspace.';
  $('new-case').disabled=locked || busy || casePicking;
  $('new-case').hidden=false;
  const firstCase=folderReady && !cases.length;setActionLabel($('new-case'),firstCase?'Create first case':'New case','plus',true);
  const createHost=root && (needsAccess || firstCase)?$('case-create-slot'):$('case-menu-create');if($('new-case').parentElement!==createHost)createHost.append($('new-case'));
  $('case-select').hidden=!cases.length;$('case-select').disabled=locked || busy || needsAccess || !cases.length;
  document.querySelector('label[for="case-select"]').textContent=!folderReady?'Cases':cases.length?'Active case':'Create your first case';
  $('create-case').disabled=locked || casePicking || !caseDestination;
  $('case-folder').disabled=locked || casePicking;
  $('case-title').readOnly=caseSaving;$('case-code').readOnly=caseSaving;
  for(const id of ['bookmark-page','capture-page','capture-screen','capture-full','capture-pdf','selection-highlight','selection-quote','selection-note','selection-entity','manual-note','export-case','archive-first'])$(id).disabled=locked || busy || !ready;
  for(const id of ['pick-root','change-root','reauthorize'])$(id).disabled=locked || busy;
  document.querySelectorAll('[data-view]').forEach(b=>b.disabled=!ready || locked);
  document.querySelectorAll('.bookmark-tools button[data-capture]').forEach(b=>b.disabled=locked || busy || bookmarkOperation || !ready);
  renderSession();
}
function openCaseDialog(){
  if(initializing || connecting || caseSaving)throw new Error('Wait for workspace setup to finish.');
  caseDestination=root && workspace && folderPermission==='granted' && !(workspace.mode==='single_case' && cases.length)?{root,workspace,label:folderLabel || root.name}:null;
  $('case-title').value='';$('case-code').value='';
  $('case-target').textContent=caseDestination?`Save in: ${caseDestination.label}`:'Choose a destination folder for this new case. Your previous case stays intact.';
  const recording=navigationState?.status==='recording';$('new-case-session').hidden=!recording;$('stop-for-new-case').checked=recording && navigationState.window_id===ownWindowId;
  $('new-case-session-label').textContent=recording?'Stop recording '+navigationState.case_label+' before creating this case':'';
  $('case-save-state').textContent=navigationState?.pending?.length?'The previous session has pending events. They must be recovered before a new recording starts.':'Materials and notes will be grouped in this case.';
  updateSetup();
  $('case-dialog').showModal();$('case-title').focus();
}
function status(message,error=false) {$('status').textContent=message;$('status').title=message;$('status').parentElement.dataset.error=String(error);const alert=document.querySelector('dialog[open] .dialog-error');if(alert){alert.hidden=!error;alert.textContent=error?message:'';}}
async function reportError(e){if(e.name!=='SiteAccessError')console.error('TraceVault:',e);status(errorText(e),true);if(root)try{await renderFolder();}catch{/* Keep the original error; source navigation stays independent. */}}
function errorText(e) {
  if(e.name==='AbortError') return "Operation cancelled";
  if(e.name==='QuotaExceededError') return "Insufficient space or quota exceeded. Free up space and try again.";
  if(e.name==='NotAllowedError') return "Workspace or site access is missing. Restore the corresponding permission.";
  if(e.name==='InvalidStateError') return "Chrome could not finish the file operation. Success is unconfirmed. Check the workspace files; selecting the folder again cannot repair damaged files.";
  return e.message || String(e);
}
function action(id,fn) {$(id).addEventListener('click',()=>{try{Promise.resolve(fn()).catch(reportError);}catch(e){reportError(e);}});}
function el(tag,text,cls) {const node=document.createElement(tag);if(text!==undefined)node.textContent=text;if(cls)node.className=cls;return node;}
function button(label,fn,text=false) {const b=el('button');if(label)setActionLabel(b,label,undefined,text);b.addEventListener('click',()=>Promise.resolve().then(fn).catch(reportError));return b;}
function setUrl(node,value,focusable=true){
  const url=String(value),tail=url.length>24?Math.min(18,Math.ceil(url.length/3)):0;
  if(node.dataset.fullUrl===url && node.classList.contains('compact-url'))return;
  node.classList.add('compact-url');node.dataset.fullUrl=url;node.dataset.tooltip=url;node.removeAttribute('title');
  if(focusable && node.tagName!=='A')node.tabIndex=0;
  node.replaceChildren(el('span',tail?url.slice(0,-tail):url,'url-start'),el('span',tail?url.slice(-tail):'','url-end'));
  refreshTooltip(node);
}
function field(dl,label,value,cls) {const dd=el('dd',value ?? '—',cls);if(/^https?:\/\/\S+$/u.test(value || ''))setUrl(dd,value);dl.append(el('dt',label),dd);}
function link(url,label) {const a=el('a',label);if(/^https?:\/\//u.test(url||'')){a.href=url;a.target='_blank';a.rel='noreferrer noopener';}return a;}
function context() {if(!root || !workspace || !activeCase) throw new Error("Choose a workspace folder and an active case");return {root,workspace,caseId:activeCase};}
async function readPreferences(){const stored=await setting('preferences');const cleaned=removeLegacyCaptureFilters(stored);if(stored && ('blockedDomains' in stored || 'allowedCaptureHosts' in stored))await setting('preferences',cleaned);preferences={...preferences,...cleaned};}
async function canWrite() {
  if(initializing || connecting || caseSaving)throw new Error('Wait for workspace setup to finish.');
  if(!root)throw new Error("Choose a workspace folder");
  const needsReconnect=!workspace || !activeCase,permission=await root.queryPermission({mode:'readwrite'});
  if(permission!=='granted'){
    await renderFolder();
    if(!navigator.userActivation.isActive)throw new Error("Chrome needs write access. Use Restore folder access at the top of the panel.");
    if(await root.requestPermission({mode:'readwrite'})!=='granted'){await renderFolder();throw new Error("Chrome denied write access. Use Restore folder access or select the same folder again.");}
    await connect(root);
  }else if(needsReconnect)await connect(root);
  await readPreferences();context();
}
async function refresh({annotations=true}={}) {
  if(activeCase && root && await root.queryPermission({mode:'read'})==='granted') {const c=context(),fresh=await exclusive(()=>loadState(c.root,c.workspace,c.caseId));if(activeCase===c.caseId && root===c.root){state=fresh;if(annotations)await broadcastAnnotations(activeCase,state,preferences.annotations,preferences.hiddenAnnotationDomains);}}
  renderList();await renderFolder();
}
async function renderFolder() {
  $('setup').hidden=!!root;$('workspace-state').hidden=!root;
  if(!root){updateSetup();return;}
  const permission=await root.queryPermission({mode:'readwrite'});
  $('folder-state').textContent=`${folderLabel || root.name} · ${permission==='granted'?"Read/write access":"Access required"}`;
  $('folder-state').title=$('folder-state').textContent;
  $('reauthorize').hidden=permission==='granted' && !!workspace;
  setActionLabel($('reauthorize'),permission==='granted'?'Reconnect folder':'Restore folder access','key',true);
  folderPermission=permission;updateSetup();
}
async function connect(handle,mode='workspace',{createChild=false}={}) {
  if(connecting || caseSaving || busy)throw new Error('Wait for the current operation before changing folders.');
  const previousWorkspaceId=workspace?.workspace_id;connecting=true;updateSetup();let recovered=0,createdIn;
  try{
  const next=await exclusive(async()=>{
    const prepared=await prepareWorkspace(handle,mode,{createChild}),found=await listCases(prepared.root,prepared.metadata);
    recovered=await recover(prepared.root,prepared.metadata,found);await setting('root',prepared.root);
    return {...prepared,found};
  });
  root=next.root;workspace=next.metadata;createdIn=next.createdIn;folderLabel=createdIn?`${createdIn} / ${root.name}`:root.name;cases=next.found;activeCase=null;state={captures:{},annotations:{},entities:{},refs:{},audit:[]};
  for(const key of Object.keys(statuses))delete statuses[key];selectedId=null;
  if(previousWorkspaceId!==workspace.workspace_id){lastDeleted=null;$('undo-delete').hidden=true;}$('details').hidden=true;
  const {activeContext}=await chrome.storage.local.get('activeContext'),saved=activeContext?.workspaceId===workspace.workspace_id?activeContext.caseId:await setting('activeCase');activeCase=cases.some(c=>c.case_id===saved)?saved:cases[0]?.case_id || null;
  await setCases();await refresh();
  if(recovered)status(`Interrupted operations found: ${recovered}. Review the history and files.`,true);
  }finally{connecting=false;updateSetup();}
  if(!cases.length && !initializing && folderPermission==='granted' && !$('case-dialog').open)openCaseDialog();
  return {createdIn,folderLabel};
}
async function setCases(publish=true) {
  $('case-select').replaceChildren(...cases.map(c=>{const o=el('option',c.code+' · '+c.title);o.value=c.case_id;o.title=c.title;return o;}));
  if(activeCase){$('case-select').value=activeCase;$('case-select').title=cases.find(c=>c.case_id===activeCase)?.title || '';await setting('activeCase',activeCase);if(publish)await chrome.storage.local.set({activeCase,activeContext:{workspaceId:workspace.workspace_id,caseId:activeCase,owner:sessionId,revision:uuid()}});}
  else if(publish && workspace)await chrome.storage.local.set({activeCase:null,activeContext:{workspaceId:workspace.workspace_id,caseId:null,owner:sessionId,revision:uuid()}});
}
async function currentTab() {
  const window=await chrome.windows.getCurrent(),tabs=await chrome.tabs.query({active:true,windowId:window.id});
  if(tabs[0]?.url?.startsWith('chrome-extension:')) {
    const stored=await setting('sourceTab:'+window.id) || await setting('sourceTab');
    if(stored){const candidate=await chrome.tabs.get(stored).catch(()=>null);if(candidate?.windowId===window.id)return candidate;}
    return null;
  }
  return tabs[0] || null;
}
async function refreshSource() {
  const revision=++sourceRevision,source=await currentTab();if(revision!==sourceRevision)return;tab=source;
  $('source-title').textContent=tab?.title || "Open an HTTP/HTTPS site";
  $('source-title').title=$('source-title').textContent;
  if(tab?.url)setUrl($('source-url'),tab.url);else{if($('source-url').hasAttribute('aria-describedby'))hideTooltip();$('source-url').textContent='No website selected';$('source-url').classList.remove('compact-url');delete $('source-url').dataset.fullUrl;delete $('source-url').dataset.tooltip;$('source-url').removeAttribute('tabindex');}
  if(tab && /^https?:/u.test(tab.url || ''))await setting('sourceTab:'+tab.windowId,tab.id);
  if(revision!==sourceRevision)return;
  let permitted=false;
  if(/^https?:/u.test(tab?.url || '')) permitted=await chrome.permissions.contains({origins:[hostPattern(tab.url)]});
  if(revision!==sourceRevision)return;
  $('site-state').textContent=permitted?"Site access enabled":/^https?:/u.test(tab?.url || '')?"Chrome restricted site access. Open extension settings and select On all sites.":"Open an HTTP/HTTPS site.";
  setActionLabel($('grant-site'),"Open Chrome site access settings");
  $('grant-site').hidden=permitted || !/^https?:/u.test(tab?.url || '');
  $('site-state').parentElement.hidden=permitted;
  $('site-annotations').hidden=!/^https?:/u.test(tab?.url || '');
  const siteHidden=/^https?:/u.test(tab?.url || '') && preferences.hiddenAnnotationDomains.includes(new URL(tab.url).hostname);
  setActionLabel($('site-annotations'),siteHidden?"Show annotations on this site":"Hide annotations on this site",siteHidden?'eye':'eye-off');
  if(activeCase && root && workspace && await root.queryPermission({mode:'read'})==='granted'){const c=context();try{const fresh=await exclusive(()=>loadState(c.root,c.workspace,c.caseId));if(revision!==sourceRevision)return;if(activeCase===c.caseId && root===c.root)state=fresh;}catch(e){await renderFolder();if(revision===sourceRevision)status(errorText(e),true);}}
  if(revision!==sourceRevision)return;
  if(source?.id) {
    try {await inject(source.id);if(revision!==sourceRevision)return;const data=await chrome.tabs.sendMessage(source.id,{type:'TV_RENDER',annotations:Object.values(state.annotations).filter(a=>a.source_url===source.url && !a.deleted),enabled:preferences.annotations && !siteHidden});if(revision===sourceRevision)Object.assign(statuses,data?.statuses);}catch { /* UI explains restricted access */ }
  }
  if(revision===sourceRevision)renderList();
}
async function runCapture(kind='page',command=null) {
  const requested=command?.tabId?await chrome.tabs.get(command.tabId):await currentTab();
  await canWrite();if(busy)throw new Error("Wait for the current capture");
  const c=context(),sourceId=requested?.id;if(command?.caseId)c.caseId=command.caseId;if(!sourceId)throw new Error("No source tab selected");
  if(!cases.some(item=>item.case_id===c.caseId))throw new Error("The queued case is missing from this workspace. Open its original folder or repeat the command.");
  const source=await chrome.tabs.get(sourceId);assertWebTab(source,preferences);if(source.url!==requested.url)throw new Error("The source changed while requesting access. Try again.");if(command?.sourceUrl && source.url!==command.sourceUrl)throw new Error("The tab URL changed after the command was queued");
  busy=true;controller=new AbortController();$('cancel').hidden=false;setBusy(true);
  try {
    const result=await capture({...c,tabId:sourceId,id:command?.id,imageUrl:command?.imageUrl,bookmarkId:command?.bookmarkId,kind,settings:preferences,signal:controller.signal,onProgress:message=>status(t(message))});
    if(!['completed','partial'].includes(result.state)){status(`${t(result.state)} · ${result.error || "No verified file"}`,true);return result;}
    status(`${t(result.state)} · ${result.evidence_number} · ${result.artifacts[0].byte_length.toLocaleString('en-US')} bytes`);
    if(c.caseId===activeCase){await refresh();showCapture(result.capture_id);}return result;
  } finally {busy=false;controller=null;$('cancel').hidden=true;setBusy(false);await refresh();}
}
function setBusy() {updateSetup();}
async function beginAnnotation(actionName,command=null) {
  const requested=command?.tabId?await chrome.tabs.get(command.tabId):await currentTab();await canWrite();const c=context(),sourceId=requested?.id;if(command?.caseId)c.caseId=command.caseId;
  let data=null;
  if(sourceId && actionName!=='manual'){const source=await chrome.tabs.get(sourceId);assertWebTab(source,preferences);if(source.url!==requested.url)throw new Error("The source changed while requesting access. Try again.");data=await selected(sourceId);}
  const sel=data?.selection;
  if(actionName!=='manual' && !sel?.exact) throw new Error("Select page text outside input fields and editors");
  if(command?.selectionText && sel.exact!==command.selectionText) throw new Error("The selection changed after opening the menu. Select the text again.");
  if(command?.selectionDigest && await sha256(new TextEncoder().encode(data.native_text ?? sel.exact))!==command.selectionDigest)throw new Error("The selection changed after opening the menu. Select the text again.");
  if(actionName==='highlight'){
    if(busy)throw new Error('Wait for the current operation');if(data.url!==requested.url)throw new Error('The source URL changed. Select the text again.');
    busy=true;setBusy(true);
    try{const annotation=await saveAnnotation({...c,tabId:sourceId,selection:sel,type:'text_highlight',note:''});await refresh();await refreshSource();if(c.caseId===activeCase)showAnnotation(annotation.annotation_id);status('Highlight saved. Use Edit to add an optional note.');await chrome.tabs.sendMessage(sourceId,{type:'TV_FEEDBACK',message:'Highlight saved. You can add a note in TraceVault.'}).catch(()=>{});return annotation;}
    finally{busy=false;setBusy(false);queueMicrotask(()=>processInbox().catch(reportError));}
  }
  pending={...c,tabId:actionName==='manual'?null:sourceId,selection:actionName==='manual'?null:sel,action:actionName,captureId:null,annotationId:null,sourceUrl:data?.url};
  $('annotation-title').textContent=actionName==='entity'?"Create entity":actionName==='manual'?"Free note":"Save selection";
  $('quote-preview').textContent=pending.selection?.exact || "Note without a quote";
  $('reference-state').textContent="Live page only; no archived evidence copy.";
  $('archive-first').hidden=actionName==='manual';$('annotation-note').value='';$('annotation-tags').value='';$('annotation-color').value='amber';
  $('entity-fields').hidden=actionName!=='entity';$('entity-label').value=sel?.exact || '';updateDuplicates();
  $('annotation-dialog').showModal();
}
function updateDuplicates() {
  const type=$('entity-type').value,value=normalize(type,$('entity-label').value);
  const candidates=Object.values(state.entities).filter(e=>e.entity_type===type && e.normalized_value===value);
  $('duplicate-info').textContent=candidates.length?`Matching values found: ${candidates.length}. Matching values do not prove identity.`:"No matching values in this case. Status: unconfirmed.";
  $('entity-existing').replaceChildren(Object.assign(el('option',"Create new (unconfirmed)"),{value:''}),...candidates.map(e=>Object.assign(el('option',"Link to "+e.label+' · '+e.entity_id),{value:e.entity_id})));
}
async function saveDialog(event) {
  event.preventDefault();if(!pending || dialogSaving)return;
  dialogSaving=true;const submit=$('annotation-form').querySelector('[type=submit]');submit.disabled=true;
  try{
  const p=pending,note=$('annotation-note').value;
  if(!p.selection?.exact && !note.trim()) throw new Error("Enter a note");
  if(p.tabId){const current=await chrome.tabs.get(p.tabId);if(current.url!==p.sourceUrl)throw new Error("The source changed. Open the editor again.");}
  const args={...p,note,color:$('annotation-color').value,type:p.action==='highlight'?'text_highlight':p.action==='note'||p.action==='manual'?'note':'quote'};
  let annotation;
  if(p.editId){await updateAnnotation(p.root,p.workspace,p.caseId,p.editId,{note,appearance:{color_token:args.color},tags:$('annotation-tags').value.split(',').map(s=>s.trim()).filter(Boolean)});}
  else {
    if(!p.annotationId){annotation=await saveAnnotation(args);p.annotationId=annotation.annotation_id;}else annotation=(await loadState(p.root,p.workspace,p.caseId)).annotations[p.annotationId];
    if($('annotation-tags').value)await updateAnnotation(p.root,p.workspace,p.caseId,annotation.annotation_id,{tags:$('annotation-tags').value.split(',').map(s=>s.trim()).filter(Boolean)});
    if(p.action==='entity')await saveEntity({...p,type:$('entity-type').value,label:$('entity-label').value,raw:p.selection.exact,annotationId:annotation.annotation_id,existingId:$('entity-existing').value || null});
  }
  await refresh();await refreshSource();status("Saved to case. Original HTML and PNG files are unchanged.");pending=null;$('annotation-dialog').close();
  }finally{dialogSaving=false;submit.disabled=false;}
}
const listClock=new Intl.DateTimeFormat('en-GB',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit',hour12:false});
function listTime(value){const date=new Date(value);return Number.isFinite(date.getTime())?listClock.format(date):'—';}
function renderList() {
  renderSession();
  $('collection').dataset.collectionView=view;
  const pathOnly=view==='audit' && $('visits-only').checked;$('collection').dataset.path=String(pathOnly);$('visits-only-label').hidden=view!=='audit';
  for(const key of ['captures','bookmarks','annotations','audit']){
    const control=document.querySelector(`nav [data-view="${key}"]`);let count=control.querySelector('.view-count');
    if(!count){count=el('span',undefined,'view-count');count.setAttribute('aria-hidden','true');control.append(count);}
    count.textContent=Object.values(state[key] || {}).filter(r=>!['annotations','bookmarks'].includes(key) || !r.deleted).length;
  }
  $('collection-title').textContent=pathOnly?'Investigation path':{captures:'Materials',bookmarks:'Bookmarks',annotations:'Highlights & notes',entities:'Entities',audit:'History'}[view];
  $('manual-note').hidden=view!=='annotations';
  $('capture-type-label').hidden=view!=='captures';$('capture-status-label').hidden=view!=='captures';$('annotation-type-label').hidden=view!=='annotations';
  const query=$('search').value.trim().toLocaleLowerCase('en'),type=$('type-filter').value,filter=$('status-filter').value,domain=$('domain-filter').value.trim().toLowerCase(),date=$('date-filter').value;
  let rows=Object.values(state[view] || {});
  if(['annotations','bookmarks'].includes(view))rows=rows.filter(a=>!a.deleted);
  const total=rows.length;
  const activeFilters=[$('search').value.trim(),domain,date,$('current-page-only').checked,pathOnly,...(view==='captures'?[type,filter]:view==='annotations'?[$('annotation-type-filter').value]:[])].filter(Boolean).length;
  $('filter-count').textContent=activeFilters?` · ${activeFilters} active`:'';
  $('reset-filters').disabled=!activeFilters;
  const annotationCounts=[['text_highlight','highlight'],['quote','quote'],['note','note']].map(([type,label])=>{const count=rows.filter(r=>r.type===type).length;return `${count} ${label}${count===1?'':'s'}`;}).join(' · ');
  $('collection-description').textContent={bookmarks:`${total} bookmark${total===1?'':'s'} · Links only until captured`,captures:`${total} saved record${total===1?'':'s'} in this case`,annotations:annotationCounts,entities:`${total} entit${total===1?'y':'ies'} in this case`,audit:`${total} history event${total===1?'':'s'} in this case`}[view];
  rows=rows.filter(r=>{
    if(pathOnly && (r.action!=='navigation_recorded' || !isSessionVisit(r.details?.event)))return false;
    if(query && !JSON.stringify(r).toLocaleLowerCase('en').includes(query))return false;
    if(view==='captures' && ((type && r.kind!==type) || (filter && r.state!==filter)))return false;
    if(view==='annotations' && $('annotation-type-filter').value && r.type!==$('annotation-type-filter').value)return false;
    const urls=recordUrls(r,state.refs);
    if(domain && !urls.some(url=>matchesDomain(url,domain)))return false;
    if($('current-page-only').checked && !urls.includes(tab?.url))return false;
    const at=r.times?.capture_started_at || r.details?.event?.observed_at || r.created_at || r.recorded_at;
    return !date || (at && at.slice(0,10)>=date);
  }).sort((a,b)=>Number(!!b.pinned)-Number(!!a.pinned) || (b.times?.capture_started_at || b.created_at || b.recorded_at || '').localeCompare(a.times?.capture_started_at || a.created_at || a.recorded_at || ''));
  const maxPage=Math.max(0,Math.ceil(rows.length/25)-1);page=Math.min(page,maxPage);$('list').replaceChildren();
  for(const row of rows.slice(page*25,page*25+25)) {
    const id=row.bookmark_id || row.capture_id || row.annotation_id || row.entity_id || row.event_id,item=el('div',undefined,'item'+(selectedId===id?' selected':''));item.setAttribute('role','listitem');
    const b=button('',()=>view==='bookmarks'?showBookmark(row.bookmark_id):view==='captures'?showCapture(row.capture_id):view==='annotations'?showAnnotation(row.annotation_id):view==='entities'?showEntity(row.entity_id):showAudit(row));b.className='item-button';
    let title,meta;const urls=[];
    if(view==='captures'){title=`${row.pinned?"Pinned · ":''}${row.evidence_number} · ${row.source.title}`;meta=`${row.kind==='webpage'?'HTML':row.capture_scope==='full_page'?"Full PNG":row.kind==='screenshot'?'PNG':"Image"} · ${t(row.state)} · ${listTime(row.times.capture_started_at)}`;urls.push({url:row.source.final_url});}
    else if(view==='bookmarks'){title=row.title;meta=`Saved copies: ${bookmarkCaptures(row.bookmark_id).length} · ${listTime(row.created_at)}`;urls.push({url:row.source_url});}
    else if(view==='annotations'){title=row.selection?.exact || row.note;meta=`${{text_highlight:'Highlight',quote:'Quote',note:'Note'}[row.type] || 'Annotation'} · ${t(statuses[row.annotation_id] || row.reattachment_status)} · ${listTime(row.created_at)}${row.tags.length?' · '+row.tags.join(', '):''}`;}
    else if(view==='entities'){title=row.label;meta=`${row.entity_type} · unconfirmed · ${row.evidence_refs.length} sources · ${listTime(row.created_at)}`;}
    else if(row.action==='navigation_recorded'){const e=row.details.event;title=`${navigationNames[e.type] || e.type}${e.title?' · '+e.title:''}`;meta=listTime(e.observed_at);if(e.previous_url)urls.push({url:e.previous_url,label:'From'});if(e.url)urls.push({url:e.url,label:e.previous_url?'To':null});}
    else {title=row.action;meta=listTime(row.recorded_at);}
    const metadata=el('span',meta,'item-meta'),at=row.times?.capture_started_at || row.details?.event?.observed_at || row.created_at || row.recorded_at;if(at)metadata.title=localTime(at);
    for(const {url,label}of urls){const line=el('span',undefined,'url-line'),value=el('span');if(label)line.append(el('span',label,'url-label'));setUrl(value,url,false);line.append(value);metadata.append(line);}
    b.append(el('span',title,'item-title'),metadata);item.append(b);if(view==='bookmarks')item.append(bookmarkTools(row));$('list').append(item);
  }
  if(!rows.length){
    const empty=el('div',undefined,'empty');
    const filtered=activeCase && total>0 && activeFilters>0;
    empty.append(el('strong',!activeCase?'Choose a workspace to start':filtered?'No matching records':{captures:'No materials yet',bookmarks:'No bookmarks yet',annotations:'No highlights or notes yet',entities:'No entities yet',audit:'No history yet'}[view]));
    empty.append(el('p',!activeCase?'Choose a folder above, then create or open a case.':filtered?'Your records are still in this case. Clear the filters to see them.':{bookmarks:'Bookmark the current page using the ribbon icon above. Save its contents later as HTML, PDF or PNG.',captures:'Use Save page above for HTML, or choose the full-page PNG or PDF icon.',annotations:'Select text on a website, right-click and choose TraceVault → Highlight selection. A note is optional.',entities:'Select text on a website and use Create entity from selection.',audit:'Saved actions will appear here.'}[view]));
    if(filtered)empty.append(button('Clear filters',resetFilters,true));
    $('list').append(empty);
  }
  $('collection').querySelector('.pagination').hidden=rows.length<=25;
  $('page-number').textContent=`${page+1} / ${maxPage+1} · ${rows.length}`;$('previous').disabled=page===0;$('next').disabled=page===maxPage;
}
function details(title,id) {$('details').hidden=false;$('details-title').textContent=title;$('details-body').replaceChildren();selectedId=id;renderList();$('details').scrollIntoView({block:'nearest'});return $('details-body');}
function referenceDetails(container,ref) {
  if(!ref)return;
  const dl=el('dl');field(dl,"Reference status",t(ref.status));field(dl,"Quote",ref.quote);field(dl,'Reference ID',ref.reference_id);field(dl,'Capture ID',ref.capture_id);field(dl,'Artifact ID',ref.artifact_id);field(dl,"First seen",localTime(ref.observed_at));field(dl,'UTC',ref.observed_at);container.append(dl);
  if(ref.source_url)container.append(link(ref.source_url,"Open original URL"));
  if(ref.capture_id && state.captures[ref.capture_id]) {
    const cap=state.captures[ref.capture_id],artifact=cap.artifacts.find(a=>a.artifact_id===ref.artifact_id);
    if(artifact){const d=el('dl');field(d,"Path",artifact.relative_path);field(d,'SHA-256',artifact.sha256,'hash');container.append(d,button("Open archived HTML",()=>openArtifact(artifact)));}
  }
}
function showCapture(id) {
  const c=state.captures[id];if(!c)return;
  const box=details(c.evidence_number,id),dl=el('dl');
  if(c.bookmark_id && state.bookmarks?.[c.bookmark_id] && !state.bookmarks[c.bookmark_id].deleted)box.append(button('Open linked bookmark',()=>{switchView('bookmarks');showBookmark(c.bookmark_id);},true));
  field(dl,"Title",c.source.title);field(dl,"Status",t(c.state));field(dl,"Original URL",c.source.original_url);field(dl,"Final URL",c.source.final_url);
  for(const [key,label] of Object.entries({capture_started_at:"Capture started",capture_finished_at:"Acquisition finished",artifact_write_started_at:"File write started",artifact_written_at:"File written",record_created_at:"Record created",first_seen_at:"First seen"})) {field(dl,label,localTime(c.times[key]));if(c.times[key])field(dl,label+' · UTC',c.times[key]);}
  field(dl,"Clock",`${c.times.clock_source} · ${c.times.timezone_id} · offset ${c.times.local_offset_minutes} min. No independent timestamp.`);field(dl,'Capture ID',c.capture_id);field(dl,"Method",c.capture_method);field(dl,"Acquisition duration (monotonic)",c.duration_ms!=null?c.duration_ms+" ms":null);field(dl,"Previous version",c.previous_capture_id);if(c.error)field(dl,"Failed",c.error);if(c.viewport)field(dl,"Tab parameters",JSON.stringify({viewport:c.viewport,pixel_width:c.pixel_width,pixel_height:c.pixel_height,page_zoom:c.page_zoom}));box.append(dl,link(c.source.final_url,"Open source site"));
  const frames=el('details');frames.append(el('summary',`Source frames (${c.artifacts.filter(a=>a.kind==='screenshot_frame').length})`));if(c.artifacts.some(a=>a.kind==='screenshot_frame'))box.append(frames);
  if(c.frame_storage==='not_retained')box.append(el('p','Compact · full-resolution lossless PNG. Intermediate source frames were not retained.','muted'));
  if(c.image_encoding)box.append(el('p',`PNG encoding: ${c.image_encoding.encoder} · ${c.image_encoding.saved_png_bytes.toLocaleString('en')} bytes · no pixel resampling.`,'muted'));
  for(const a of c.artifacts) {
    const parent=a.kind==='screenshot_frame'?frames:box;
    const d=el('dl');field(d,"File",a.relative_path);field(d,"Size",a.byte_length+" bytes");field(d,'SHA-256',a.sha256,'hash');field(d,"Write verification",a.verification_status);if(a.derivation)field(d,"Derived PDF",JSON.stringify(a.derivation));parent.append(d);
    const row=el('div',undefined,'actions');row.append(button(a.kind==='derived_pdf'?"Copy PDF path":"Open file",async()=>{if(a.kind==='derived_pdf'){await navigator.clipboard.writeText(a.relative_path);status("Workspace-relative PDF path copied. Open it from the workspace in your PDF viewer.");}else await openArtifact(a);}),button("Verify checksum",async()=>{const result=await verifyArtifact(root,workspace,c.case_id,a);status(result.ok?"SHA-256 verified by reading the file again":"Checksum MISMATCH. File changed: "+result.actual,!result.ok);}),button("Copy SHA-256",()=>navigator.clipboard.writeText(a.sha256)),button(a.kind==='derived_pdf'?"Export PDF":"Export original",()=>exportOriginal(a,c.case_id)));if(a.mime_type==='image/png' && a.kind!=='screenshot_frame')row.append(button("Create PDF",()=>convertPdf(c,a)));parent.append(row);
  }
  box.append(button("Copy citation",async()=>{await navigator.clipboard.writeText(citation(c));status("Citation copied: URL, UTC, Capture ID and SHA-256");}));
  const pin=button(c.pinned?"Unpin":"Pin",async()=>{await exclusive(async()=>{const fresh=await loadState(root,workspace,c.case_id);await append(root,workspace,c.case_id,'capture_pinned','captures',{...fresh.captures[id],pinned:!fresh.captures[id].pinned});});await refresh();showCapture(id);});box.append(pin);
  if(['failed','interrupted','cancelled','partial'].includes(c.state))box.append(button("Capture new version",async()=>{await refreshSource();if(tab?.url!==c.source.final_url)throw new Error("Open the source URL and click the TraceVault extension icon before retrying");await runCapture(c.capture_request || (c.kind==='webpage'?'page':c.kind==='screenshot'?'screen':'image'),{id:uuid(),tabId:tab.id,caseId:c.case_id,sourceUrl:c.source.final_url,imageUrl:c.image_source_url});}));
  if(c.warnings.length){box.append(el('h2',"Capture diagnostics"));const pre=el('pre',JSON.stringify(c.warnings,null,2));box.append(pre);}
  const refs=Object.values(state.refs).filter(r=>r.capture_id===id);if(refs.length)box.append(el('p',`Linked evidence references: ${refs.length}`));
  if(c.kind==='webpage' && ['completed','partial'].includes(c.state))box.append(button('Compare saved versions',()=>openComparison(c),true));
}
function openComparison(record){
  const versions=Object.values(state.captures).filter(c=>c.kind==='webpage' && ['completed','partial'].includes(c.state) && c.source.final_url===record.source.final_url && c.artifacts.some(a=>a.mime_type==='text/html')).sort((a,b)=>a.times.capture_started_at.localeCompare(b.times.capture_started_at));
  comparison={...context(),caseId:record.case_id,versions};comparisonRevision++;
  for(const id of ['compare-before','compare-after'])$(id).replaceChildren(...versions.map(c=>Object.assign(el('option',c.evidence_number+' · '+localTime(c.times.capture_started_at)+(c.state==='partial'?' · Partial':'')),{value:c.capture_id})));
  const index=versions.findIndex(c=>c.capture_id===record.capture_id);$('compare-after').value=versions[index>0?index:Math.min(1,versions.length-1)]?.capture_id || '';$('compare-before').value=versions[Math.max(0,index-1)]?.capture_id || '';
  $('compare-source').textContent=record.source.final_url;$('compare-result').replaceChildren();$('compare-files').replaceChildren();$('compare-status').textContent=versions.length<2?'Save another HTML version of this URL, then compare the two saved versions.':'Compare archived document text. Layout, images, CSS and embedded frames are not compared.';
  updateCompareControls();$('comparison-dialog').showModal();
}
function updateCompareControls(){
  $('compare-run').disabled=comparing || !comparison || comparison.versions.length<2 || $('compare-before').value===$('compare-after').value;
  $('compare-before').disabled=comparing;$('compare-after').disabled=comparing;
}
action('compare-run',async()=>{
  if(!comparison || comparing)return;const c=comparison,revision=++comparisonRevision,ids=[$('compare-before').value,$('compare-after').value];
  if(ids[0]===ids[1])throw new Error('Choose two different saved versions.');
  comparing=true;updateCompareControls();$('compare-status').textContent='Reading and verifying both original files…';$('compare-result').replaceChildren();$('compare-files').replaceChildren();
  try{
    const fresh=await exclusive(()=>loadState(c.root,c.workspace,c.caseId)),records=ids.map(id=>fresh.captures[id]);
    if(records.some(r=>!r || r.kind!=='webpage') || records[0].source.final_url!==records[1].source.final_url)throw new Error('Choose two HTML captures of the same source URL in the original case.');
    const artifacts=records.map(r=>r.artifacts.find(a=>a.mime_type==='text/html'));
    if(artifacts.some(a=>!a || a.byte_length>8*1024*1024))throw new Error('Text comparison supports saved HTML files up to 8 MB each. Open larger originals separately.');
    const originals=[];for(const artifact of artifacts)originals.push(await readVerifiedFile(c.root,artifact));
    const result=compareText(archivedText(await originals[0].text()),archivedText(await originals[1].text()));
    if(revision!==comparisonRevision || !$('comparison-dialog').open)return;
    const dl=el('dl');records.forEach((r,i)=>{field(dl,i?'After capture':'Before capture',r.evidence_number+' · '+localTime(r.times.capture_started_at));field(dl,i?'After SHA-256':'Before SHA-256',artifacts[i].sha256,'hash');});$('compare-files').append(dl);
    $('compare-status').textContent=result.same?(artifacts[0].sha256===artifacts[1].sha256?'Verified files are identical.':'Verified HTML files differ; extracted document text is unchanged.'):result.method==='changed_region'?'Large change: before/after regions shown, including any unchanged lines inside those regions.':'Text differences · − removed, + added. Originals are unchanged.';
    const shown=result.rows.slice(0,1500);for(const row of shown){const line=el('div',`${{added:'+ ',removed:'− ',equal:'  '}[row.kind]}${row.text}`,'diff-line diff-'+row.kind);$('compare-result').append(line);}
    if(result.rows.length>shown.length)$('compare-result').append(el('p',`Showing ${shown.length} of ${result.rows.length} comparison lines. Open the originals for the complete text.`,'muted'));
  }catch(e){if(revision===comparisonRevision){$('compare-status').textContent=errorText(e);$('compare-result').replaceChildren();$('compare-files').replaceChildren();}throw e;}
  finally{comparing=false;updateCompareControls();}
});
for(const id of ['compare-before','compare-after'])$(id).addEventListener('change',()=>{comparisonRevision++;$('compare-result').replaceChildren();$('compare-files').replaceChildren();$('compare-status').textContent='Run comparison to verify and compare the selected versions.';updateCompareControls();});
$('comparison-dialog').addEventListener('close',()=>{comparisonRevision++;comparison=null;$('compare-result').replaceChildren();$('compare-files').replaceChildren();});
function showAnnotation(id) {
  const a=state.annotations[id];if(!a)return;const box=details("Annotation",id);box.append(el('blockquote',a.selection?.exact || ''),el('p',a.note));const dl=el('dl');field(dl,"Created",localTime(a.created_at));field(dl,"Updated",localTime(a.updated_at));field(dl,"Anchor status",t(statuses[id] || a.reattachment_status));field(dl,"Tags",a.tags.join(', '));box.append(dl);referenceDetails(box,state.refs[a.reference_id]);
  const row=el('div',undefined,'actions');row.append(button("Edit",()=>editAnnotation(a)),button(a.hidden?"Show":"Hide",async()=>{await updateAnnotation(root,workspace,a.case_id,id,{hidden:!a.hidden});await refresh();await refreshSource();showAnnotation(id);}),button("Go to selection",async()=>{await refreshSource();if(tab?.url!==a.source_url)throw new Error("Open the original URL first");const result=await chrome.tabs.sendMessage(tab.id,{type:'TV_SCROLL',id});status(t(result.status));}),button("Delete annotation",async()=>{const c={...context(),caseId:a.case_id};await updateAnnotation(c.root,c.workspace,c.caseId,id,{deleted:true});lastDeleted={...c,id};$('undo-delete').hidden=false;await refresh();$('details').hidden=true;status("Annotation removed from the list. Undo is available.");}));box.append(row);
}
function editAnnotation(a) {
  pending={...context(),caseId:a.case_id,editId:a.annotation_id,selection:a.selection,action:'edit',tabId:null};$('annotation-title').textContent="Edit annotation";$('quote-preview').textContent=a.selection?.exact || "No quote";$('reference-state').textContent="The original evidence reference is preserved";$('archive-first').hidden=true;$('annotation-note').value=a.note;$('annotation-color').value=a.appearance.color_token;$('annotation-tags').value=a.tags.join(', ');$('entity-fields').hidden=true;$('annotation-dialog').showModal();
}
function showEntity(id) {
  const e=state.entities[id];if(!e)return;const box=details(e.label,id),dl=el('dl');field(dl,'Entity ID',e.entity_id);field(dl,"Type",e.entity_type);field(dl,"Original value",e.raw_value);field(dl,"Normalized value",e.normalized_value);field(dl,"Verification","Unconfirmed; confidence not assessed");field(dl,"Created",localTime(e.created_at));box.append(dl);
  for(const ref of e.evidence_refs)referenceDetails(box,state.refs[ref]);
  box.append(el('p',"Use Export case JSON to export entities with their source references.",'muted'));
}
function showAudit(event) {
  if(event.action!=='navigation_recorded'){details('History event',event.event_id).append(el('pre',JSON.stringify(event,null,2)));return;}
  const value=event.details.event,artifact=event.details.artifact,box=details(navigationNames[value.type] || value.type,event.event_id),dl=el('dl');
  field(dl,'Observed',localTime(value.observed_at));field(dl,'UTC',value.observed_at);field(dl,'Session ID',value.session_id);field(dl,'Previous URL',value.previous_url);field(dl,'Title',value.title);field(dl,'Reason',value.reason);field(dl,'File',artifact.relative_path);field(dl,'SHA-256',artifact.sha256,'hash');box.append(dl);
  if(value.url)box.append(link(value.url,'Open recorded URL'));
  box.append(button('Verify checksum',async()=>{const result=await verifyArtifact(root,workspace,event.case_id,artifact);status(result.ok?'SHA-256 verified':'Session event checksum mismatch',!result.ok);}));
  const raw=el('details');raw.append(el('summary','Event metadata'),el('pre',JSON.stringify(value,null,2)));box.append(raw);
}
async function convertPdf(record,source){
  await canWrite();if(busy)throw new Error("Wait for the current operation");const c={...context(),caseId:record.case_id};busy=true;setBusy(true);status("Creating PDF from verified PNG…");
  try{const pdf=await convertScreenshotToPdf(c.root,c.workspace,c.caseId,record.capture_id,source.artifact_id,preferences);status("PDF written and verified: "+pdf.relative_path);if(activeCase===c.caseId){await refresh();showCapture(record.capture_id);}}finally{busy=false;setBusy(false);}
}
async function openArtifact(artifact) {
  const file=await readVerifiedFile(root,artifact);
  if(artifact.mime_type==='application/pdf')throw new Error("Open PDFs from the workspace in your PDF viewer");
 if(viewerUrl)URL.revokeObjectURL(viewerUrl);
  viewerUrl=URL.createObjectURL(new Blob([await file.arrayBuffer()],{type:artifact.mime_type}));$('viewer-content').replaceChildren();
  const node=document.createElement(artifact.mime_type==='text/html'?'iframe':'img');
  if(node.tagName==='IFRAME'){node.setAttribute('sandbox','');node.setAttribute('referrerpolicy','no-referrer');node.title="Isolated archived HTML preview";}else node.alt="Original image";
  node.src=viewerUrl;$('viewer-content').append(node);$('viewer').showModal();
}
async function exportOriginal(artifact,caseId) {
  const file=await readVerifiedFile(root,artifact),path=casePath(workspace,caseId)+`exports/${uuid()}__${artifact.relative_path.split('/').at(-1)}`;
  await exclusive(async()=>{await writeNew(root,path,file,artifact.mime_type);await append(root,workspace,caseId,'original_exported',null,null,{source:artifact.relative_path,relative_path:path});});status("Original copy written: "+path);
}
async function processInbox() {
  if(!root || !workspace || !activeCase || initializing || connecting || caseSaving || busy || $('annotation-dialog').open)return;
  const drained=await navigator.locks.request('tracevault-inbox:'+workspace.workspace_id,{ifAvailable:true},async lock=>{
    if(!lock)return;
    const values=await chrome.storage.local.get(null),commands=Object.entries(values).filter(([key])=>key.startsWith('command:')).sort((a,b)=>a[1].created_at.localeCompare(b[1].created_at));
    for(const [key,command] of commands) {
      if($('annotation-dialog').open || busy)break;
      if(command.workspaceId && command.workspaceId!==workspace.workspace_id)continue;
      const receiptCase=command.caseId || activeCase;
      if(!cases.some(c=>c.case_id===receiptCase)){status("This command belongs to another workspace. Repeat it in the correct case.",true);await chrome.storage.local.remove(key);continue;}
      // A durable receipt prevents reprocessing a selection command after a crash.
      const prior=await exclusive(()=>loadState(root,workspace,receiptCase));
      if(prior.audit.some(e=>e.action==='command_received' && e.details.command_id===command.id)){
        if(!prior.captures[command.id] && !prior.audit.some(e=>e.action==='command_completed' && e.details.command_id===command.id)){await exclusive(()=>append(root,workspace,receiptCase,'command_interrupted',null,null,{command_id:command.id,reason:"Interrupted before an evidence record was created. Repeat the action explicitly."}));status("Command interrupted before the evidence record. Repeat the action.",true);}
        await chrome.storage.local.remove(key);continue;
      }
      await exclusive(()=>append(root,workspace,receiptCase,'command_received',null,null,{command_id:command.id,session:sessionId}));
      try {if(['page','screen','image'].includes(command.action))await runCapture(command.action,command);else if(['delete-highlight','edit-highlight'].includes(command.action))await contextHighlight(command);else await beginAnnotation(command.action,command);await exclusive(()=>append(root,workspace,receiptCase,'command_completed',null,null,{command_id:command.id}));}
      catch(e){status(errorText(e),true);await chrome.tabs.sendMessage(command.tabId,{type:'TV_FEEDBACK',message:errorText(e),error:true}).catch(()=>{});await exclusive(()=>append(root,workspace,receiptCase,'command_failed',null,null,{command_id:command.id,error:errorText(e)}));}
      finally{await chrome.storage.local.remove(key);}
    }
    return true;
  });
  if(drained && !busy && !$('annotation-dialog').open){const values=await chrome.storage.local.get(null);if(Object.entries(values).some(([k,c])=>k.startsWith('command:') && (!c.workspaceId || c.workspaceId===workspace.workspace_id)))queueMicrotask(()=>processInbox().catch(e=>status(errorText(e),true)));}
}
async function contextHighlight(command){
  await canWrite();if(!command.annotationId)throw new Error('Right-click a visible TraceVault highlight to use this action.');
  const source=await chrome.tabs.get(command.tabId);if(source.url!==command.sourceUrl || source.url!==command.contextUrl)throw new Error('The source changed after opening the context menu.');
  const c={...context(),caseId:command.caseId},fresh=await exclusive(()=>loadState(c.root,c.workspace,c.caseId)),a=fresh.annotations[command.annotationId];
  if(!a || a.deleted || a.type!=='text_highlight' || a.source_url!==source.url)throw new Error('This highlight is no longer available in its original case.');
  if(command.action==='edit-highlight'){editAnnotation(a);return;}
  await updateAnnotation(c.root,c.workspace,c.caseId,a.annotation_id,{deleted:true});lastDeleted={...c,id:a.annotation_id};$('undo-delete').hidden=false;await refresh();await refreshSource();$('details').hidden=true;status('Highlight deleted. Undo is available.');
  await chrome.tabs.sendMessage(command.tabId,{type:'TV_FEEDBACK',message:'Highlight deleted. Undo is available in TraceVault.'}).catch(()=>{});
}
action('pick-root',async()=>{const handle=await showDirectoryPicker({mode:'readwrite',id:'tracevault'}),result=await connect(handle,$('workspace-mode').value,{createChild:true});status(result.createdIn?`Created workspace: ${result.folderLabel}`:"Folder access verified by writing and reading a test file");});
action('change-root',async()=>{const handle=await showDirectoryPicker({mode:'readwrite',id:'tracevault'}),result=await connect(handle,workspace?.mode || 'workspace',{createChild:true});status(result.createdIn?`Created workspace: ${result.folderLabel}`:"Workspace connected");});
action('reauthorize',async()=>{if(!root)throw new Error("Choose a workspace folder");if(await root.requestPermission({mode:'readwrite'})!=='granted'){await renderFolder();throw new Error("Chrome denied write access. Use Change workspace folder to select the same folder again.");}await connect(root);status("Folder access restored and verified by writing and reading");});
action('new-case',openCaseDialog);
action('case-folder',async()=>{
  const handle=await showDirectoryPicker({mode:'readwrite',id:'tracevault-new-case'});casePicking=true;updateSetup();
  try{
    const selected=await exclusive(async()=>{
      let prepared=await prepareWorkspace(handle,'workspace',{createChild:true});
      if(prepared.metadata.mode==='single_case' && (await listCases(prepared.root,prepared.metadata)).length)prepared=await prepareWorkspace(handle,'workspace',{forceChild:true});
      await listCases(prepared.root,prepared.metadata);return prepared;
    });
    caseDestination={root:selected.root,workspace:selected.metadata,label:selected.createdIn?selected.createdIn+' / '+selected.root.name:selected.root.name};
    $('case-target').textContent='Save in: '+caseDestination.label;
  }finally{casePicking=false;updateSetup();}
});
$('case-form').addEventListener('submit',event=>{
  event.preventDefault();if(caseSaving)return;
  (async()=>{
    if(initializing || connecting || casePicking || !$('case-dialog').open || !caseDestination)throw new Error('Choose a destination folder before creating a case.');
    const target=caseDestination,title=$('case-title').value,code=$('case-code').value;
    caseSaving=true;updateSetup();$('case-save-state').textContent='Creating case…';let saved=false,stopError=null;
    try{
      if(await target.root.queryPermission({mode:'readwrite'})!=='granted')throw new Error('Choose a destination folder with write access.');
      if($('stop-for-new-case').checked && navigationState?.status==='recording')try{await sessionCommand('TV_SESSION_STOP');}catch(e){stopError=e;}
      const c=await exclusive(()=>createCase(target.root,target.workspace,title,code));saved=true;
      if(workspace?.workspace_id!==target.workspace.workspace_id){lastDeleted=null;$('undo-delete').hidden=true;}
      await setting('root',target.root);root=target.root;workspace=target.workspace;folderLabel=target.label;folderPermission='granted';cases=await exclusive(()=>listCases(root,workspace));activeCase=c.case_id;state={captures:{},annotations:{},entities:{},refs:{},audit:[]};page=0;$('details').hidden=true;selectedId=null;
      for(const key of Object.keys(viewFilters))delete viewFilters[key];for(const key of Object.keys(statuses))delete statuses[key];view='captures';document.querySelectorAll('[data-view]').forEach(b=>{if(b.dataset.view===view)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});resetFilters();
      await setCases();await refresh();$('case-dialog').close();status(stopError?'Case created. Previous recording needs recovery: '+errorText(stopError):'Case created',!!stopError);
    }catch(e){if(saved)$('case-dialog').close();throw e;}
    finally{caseSaving=false;updateSetup();$('case-save-state').textContent='Materials and notes will be grouped in this case.';}
    await processInbox();
  })().catch(reportError);
});
$('case-dialog').addEventListener('close',()=>{caseDestination=null;updateSetup();});
$('case-select').addEventListener('change',()=>{(async()=>{activeCase=$('case-select').value;await setCases();await exclusive(()=>append(root,workspace,activeCase,'case_activated',null,null));page=0;$('details').hidden=true;await refresh();await refreshSource();})().catch(e=>status(errorText(e),true));});
action('refresh-source',refreshSource);
action('grant-site',()=>chrome.tabs.create({url:'chrome://extensions/?id='+chrome.runtime.id}));
action('session-start',async()=>{
  if(recorderBusy)return;recorderBusy=true;renderSession();
  try{
    await canWrite();const c=context(),id=uuid(),window=await chrome.windows.getCurrent(),info=cases.find(item=>item.case_id===c.caseId);
    await setting('session-target:'+id,{...c,caseLabel:info.code+' · '+info.title});
    const source=await currentTab();await sessionCommand('TV_SESSION_START',{sessionId:id,windowId:window.id,sourceTabId:source?.id});status('Recording this window. URLs and titles only.');await refresh();
  }finally{recorderBusy=false;renderSession();}
});
action('session-stop',async()=>{await sessionCommand('TV_SESSION_STOP');status('Session stopped and saved.');await refresh();});
action('session-retry',async()=>{await sessionCommand('TV_SESSION_RETRY');status('Pending session events saved.');await refresh();});
action('session-journal',()=>{const id=selectedSessionId();if(!id)return;switchView('audit');resetFilters();$('search').value=id;$('visits-only').checked=true;renderList();$('collection').scrollIntoView({block:'start'});});
action('session-export',async()=>{await canWrite();const id=selectedSessionId(),c=context();const artifact=await exportSession(c.root,c.workspace,c.caseId,id);status('Session export written and verified: '+artifact.relative_path);await refresh();});
action('capture-page',()=>runCapture('page'));action('capture-screen',()=>runCapture('screen'));action('capture-full',()=>runCapture('full'));action('capture-pdf',()=>runCapture('pdf'));action('cancel',()=>controller?.abort());
for(const name of ['highlight','quote','note','entity'])action('selection-'+name,()=>beginAnnotation(name));action('manual-note',()=>beginAnnotation('manual'));
action('archive-first',async()=>{if(!pending)return;const p=pending;const source=await chrome.tabs.get(p.tabId);if(source.url!==p.sourceUrl)throw new Error("URL changed");const result=await runCapture('page',{tabId:p.tabId,caseId:p.caseId,id:uuid()});if(!['completed','partial'].includes(result.state))throw new Error("Archive not verified");p.captureId=result.capture_id;$('reference-state').textContent=`Linked to ${result.evidence_number} · ${result.capture_id}`;});
$('annotation-form').addEventListener('submit',e=>saveDialog(e).catch(reportError));
$('entity-type').replaceChildren(...ENTITY_TYPES.map(type=>Object.assign(el('option',t(type)),{value:type})));$('entity-type').addEventListener('change',updateDuplicates);$('entity-label').addEventListener('input',updateDuplicates);
document.querySelectorAll('[data-close-dialog]').forEach(b=>b.addEventListener('click',()=>b.closest('dialog').close()));
$('annotation-dialog').addEventListener('close',()=>processInbox().catch(e=>status(errorText(e),true)));
document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>switchView(b.dataset.view)));
for(const id of filterIds.filter(id=>id!=='current-page-only'))$(id).addEventListener('input',()=>{page=0;renderList();});
action('previous',()=>{page--;renderList();});action('next',()=>{page++;renderList();});action('close-details',()=>{$('details').hidden=true;selectedId=null;renderList();});
action('close-viewer',()=>{$('viewer').close();});
$('viewer').addEventListener('close',()=>{$('viewer-content').replaceChildren();if(viewerUrl)URL.revokeObjectURL(viewerUrl);viewerUrl=null;});
action('export-case',async()=>{await canWrite();const path=await exportCase(root,workspace,cases.find(c=>c.case_id===activeCase));status("Export written to the workspace: "+path);await refresh();});
action('workspace',()=>chrome.tabs.create({url:chrome.runtime.getURL('panel.html?workspace=1')}));
action('settings-toggle',()=>{$('theme').value=preferences.theme;$('paused').checked=preferences.paused;$('annotations-toggle').checked=preferences.annotations;$('max-size').value=preferences.maxBytes/1024/1024;$('screenshot-storage').value=preferences.screenshotStorage;$('settings').showModal();$('settings-toggle').setAttribute('aria-expanded','true');});
$('settings').addEventListener('close',()=>{$('settings-toggle').setAttribute('aria-expanded','false');document.documentElement.dataset.theme=preferences.theme;});
action('shortcuts',()=>chrome.tabs.create({url:'chrome://extensions/shortcuts'}));
$('theme').addEventListener('change',()=>{document.documentElement.dataset.theme=$('theme').value;});
action('save-settings',async()=>{const mb=Number($('max-size').value);if(!Number.isFinite(mb) || mb<1 || mb>256)throw new Error("Limit: 1–256 MB");if($('paused').checked && navigationState?.status==='recording')await sessionCommand('TV_SESSION_STOP');preferences={...preferences,theme:$('theme').value,paused:$('paused').checked,annotations:$('annotations-toggle').checked,maxBytes:mb*1024*1024,screenshotStorage:$('screenshot-storage').value};await setting('preferences',preferences);renderSession();await broadcastAnnotations(activeCase,state,preferences.annotations,preferences.hiddenAnnotationDomains);await refreshSource();$('settings').close();status("Settings saved");});
async function toggleAnnotations(){preferences.annotations=!preferences.annotations;$('annotations-toggle').checked=preferences.annotations;await setting('preferences',preferences);await broadcastAnnotations(activeCase,state,preferences.annotations,preferences.hiddenAnnotationDomains);await refreshSource();status(preferences.annotations?'Annotations enabled':'Annotations hidden');}
action('site-annotations',async()=>{const host=new URL(tab.url).hostname;preferences.hiddenAnnotationDomains=preferences.hiddenAnnotationDomains.includes(host)?preferences.hiddenAnnotationDomains.filter(h=>h!==host):[...preferences.hiddenAnnotationDomains,host];await setting('preferences',preferences);await broadcastAnnotations(activeCase,state,preferences.annotations,preferences.hiddenAnnotationDomains);await refreshSource();});
action('undo-delete',async()=>{if(!lastDeleted)return;const c=lastDeleted;await updateAnnotation(c.root,c.workspace,c.caseId,c.id,{deleted:false});lastDeleted=null;$('undo-delete').hidden=true;await refresh();await refreshSource();status("Annotation restored in its original case");});
action('reset-filters',resetFilters);
$('current-page-only').addEventListener('change',()=>{page=0;renderList();});
const commandActions=[
  {id:'capture-page',label:"Save page as HTML"},
  {id:'capture-screen',label:"Capture visible area as PNG"},
  {id:'capture-full',label:"Capture full page as PNG"},
  {id:'capture-pdf',label:"Capture page as PDF (raster image)"},
  {id:'session-start',label:"Start recording this window"},
  {id:'session-stop',label:"Stop browsing session"},
  {id:'session-journal',label:"Open browsing session journal"},
  {id:'session-export',label:"Export browsing session as JSON"},
  {id:'selection-highlight',label:"Highlight selected quote"},
  {id:'selection-entity',label:"Create entity from selection"},
  {id:'note',label:"Create free note",run:()=>beginAnnotation('manual')},
  {id:'search',label:"Find materials",run:focusSearch},
  {id:'current-page',label:"Show only the current page",run:()=>{$('details').hidden=true;$('current-page-only').checked=true;page=0;renderList();}},
  {id:'reset-filters',label:"Reset all filters"},
  {id:'export-case',label:"Export case as JSON"},
  {id:'annotations',label:"Show or hide annotations",run:toggleAnnotations},
  {id:'settings-toggle',label:"Open settings"},
  {id:'shortcuts',label:"Configure Chrome keyboard shortcuts"}
];
function renderCommands(){
  const query=$('command-search').value.toLocaleLowerCase('en');
  const items=commandActions.filter(c=>c.label.toLocaleLowerCase('en').includes(query));
  $('command-results').replaceChildren(...items.map(command=>{const b=button(command.label,async()=>{$('command-dialog').close();if(command.run)await command.run();else $(command.id).click();},true);setActionLabel(b,command.label,$(command.id)?.dataset.icon || 'note',true);b.dataset.command=command.id;b.disabled=!!$(command.id)?.disabled || (command.id==='note' && busy);return b;}));
  if(!items.length)$('command-results').append(el('p',"No matching commands",'muted'));
}
function openCommands(){if(document.querySelector('dialog[open]'))return;renderCommands();$('command-dialog').showModal();$('command-search').focus();$('command-search').select();}
action('command-menu',openCommands);$('command-search').addEventListener('input',renderCommands);
// Native popovers provide Escape/outside dismissal. Keep actions as the original
// buttons, so picker user activation and command handlers remain unchanged.
function closeActionMenus(){document.querySelectorAll('[popover]:popover-open').forEach(menu=>menu.hidePopover());hideTooltip();}
for(const menu of document.querySelectorAll('[popover]')){
  menu.addEventListener('toggle',e=>{
    if(e.newState!=='open'){hideTooltip();return;}
    const invoker=document.querySelector(`[popovertarget="${menu.id}"]`),r=invoker.getBoundingClientRect(),bounds=menu.getBoundingClientRect();
    menu.style.left=Math.max(8,Math.min(innerWidth-bounds.width-8,r.right-bounds.width))+'px';
    menu.style.top=Math.max(8,Math.min(innerHeight-bounds.height-8,r.bottom+4))+'px';
  });
}
document.addEventListener('click',e=>{if(e.target.closest('[popover] button'))closeActionMenus();},true);
window.addEventListener('resize',closeActionMenus);document.querySelector('main').addEventListener('scroll',closeActionMenus);
$('command-dialog').addEventListener('keydown',e=>{
  const buttons=[...$('command-results').querySelectorAll('button:not(:disabled)')],index=buttons.indexOf(document.activeElement);
  if(['ArrowDown','ArrowUp'].includes(e.key) && buttons.length){e.preventDefault();buttons[index<0?(e.key==='ArrowDown'?0:buttons.length-1):(index+(e.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length].focus();}
  if(e.key==='Enter' && document.activeElement===$('command-search') && buttons.length){e.preventDefault();buttons[0].click();}
});
document.addEventListener('keydown',e=>{
  if(e.isComposing)return;
  if(e.ctrlKey && e.shiftKey && e.code==='Space' && !e.altKey && !e.metaKey){e.preventDefault();openCommands();return;}
  if(e.ctrlKey && e.key==='Enter' && $('annotation-dialog').open){e.preventDefault();$('annotation-form').requestSubmit();return;}
  if(e.key==='/' && !e.ctrlKey && !e.altKey && !e.metaKey && !document.querySelector('dialog[open]') && !e.target.closest('input,textarea,select,[contenteditable]')){e.preventDefault();focusSearch();return;}
  if(e.key==='Escape' && busy && !document.querySelector('dialog[open]'))controller?.abort();
});
async function refreshShortcuts(){
  const commands=await chrome.commands.getAll();
  $('shortcut-list').replaceChildren(...commands.filter(c=>c.name!=='_execute_action' || c.shortcut).map(c=>{const line=el('p',undefined,'shortcut-line');line.append(el('span',c.description?.replace(/^TraceVault: /u,'') || 'Open TraceVault'),el('kbd',c.shortcut || "Not assigned"));return line;}));
  const labels={'capture-page':'capture-page','capture-screen':'capture-screen','add-highlight':'selection-highlight'};
  for(const c of commands)if(labels[c.name]){
    const control=$(labels[c.name]),tip=c.shortcut?`${c.description} · ${c.shortcut}`:"Shortcut not assigned. Settings → Chrome keyboard shortcuts.";
    setActionLabel(control,control.id==='capture-page'?'Save page':control.textContent.trim() || c.description,undefined,true);control.dataset.tooltip=tip;
  }
}
action('refresh-shortcuts',refreshShortcuts);
window.addEventListener('focus',()=>refreshShortcuts().catch(()=>{}));
chrome.storage.onChanged.addListener(changes=>{
  if(changes.navigationRecorder){
    navigationState=changes.navigationRecorder.newValue;renderSession();
    if(navigationState?.status!=='recording'){clearTimeout(sessionRefreshTimer);sessionRefreshTimer=null;refresh().catch(reportError);}
    else if(!sessionRefreshTimer)sessionRefreshTimer=setTimeout(()=>{sessionRefreshTimer=null;refresh().catch(reportError);},2000);
  }
  if(Object.keys(changes).some(k=>k.startsWith('command:')))processInbox().catch(e=>status(errorText(e),true));
  const next=changes.activeContext?.newValue;
  if(next && next.owner!==sessionId && next.workspaceId===workspace?.workspace_id && next.caseId!==activeCase){
    const revision=++syncRevision;activeCase=next.caseId;page=0;$('details').hidden=true;
    (async()=>{const found=await exclusive(()=>listCases(root,workspace));if(revision!==syncRevision)return;cases=found;await setCases(false);await refresh();await refreshSource();if(pending)status("The case changed in another window. This editor will save to the original case.");})().catch(e=>status(errorText(e),true));
  }
});
function scheduleSource(){clearTimeout(sourceTimer);sourceTimer=setTimeout(()=>refreshSource().catch(e=>status(errorText(e),true)),80);}
chrome.tabs.onActivated.addListener(scheduleSource);
chrome.tabs.onUpdated.addListener((_id,info)=>{if(info.url || info.title || info.status)scheduleSource();});
chrome.tabs.onRemoved.addListener(scheduleSource);
chrome.permissions.onRemoved.addListener(scheduleSource);
chrome.permissions.onAdded.addListener(scheduleSource);
window.addEventListener('focus',scheduleSource);
async function init() {
  ownWindowId=(await chrome.windows.getCurrent()).id;navigationState=(await chrome.storage.local.get('navigationRecorder')).navigationRecorder || null;renderSession();
  if(new URL(location.href).searchParams.has('workspace'))document.body.classList.add('workspace');
  await readPreferences();document.documentElement.dataset.theme=preferences.theme;$('theme').value=preferences.theme;$('paused').checked=preferences.paused;$('max-size').value=preferences.maxBytes/1024/1024;$('annotations-toggle').checked=preferences.annotations;
  const handle=await setting('root');
  if(handle) {
    root=handle;
    if(await root.queryPermission({mode:'readwrite'})==='granted'){await connect(root);if($('status').textContent==="Initializing…")status(activeCase?"Workspace connected":"Workspace connected. Create a case");}
    else {await renderFolder();status("Restore folder access to continue the previous case, or choose New case for a different destination.",true);}
  } else status("Choose a folder, then create a case");
  await refreshShortcuts();await refreshSource();await processInbox();
}
updateSetup();
refreshSource().catch(()=>{});
init().catch(reportError).finally(()=>{initializing=false;updateSetup();if(workspace && !cases.length && folderPermission==='granted' && !$('case-dialog').open)openCaseDialog();processInbox().catch(reportError);});

function bookmarkCaptures(id){return Object.values(state.captures).filter(c=>c.bookmark_id===id && ['completed','partial'].includes(c.state));}
function bookmarkTools(record){
  const row=el('div',undefined,'actions bookmark-tools');
  row.setAttribute('role','group');row.setAttribute('aria-label','Bookmark actions');
  for(const [label,kind]of [['Save HTML','page'],['Save PDF','pdf'],['Save full-page PNG','full']]){const b=button(label,()=>captureBookmark(record,kind));b.dataset.capture=kind;b.disabled=busy || bookmarkOperation;row.append(b);}
  row.append(button('Open bookmark',()=>chrome.tabs.create({url:record.source_url,active:true})));
  return row;
}
function showBookmark(id){
  const b=state.bookmarks?.[id];if(!b || b.deleted)return;const box=details('Bookmark',id),dl=el('dl');
  field(dl,'Title',b.title);field(dl,'URL',b.source_url);field(dl,'Bookmarked',localTime(b.created_at));field(dl,'UTC',b.created_at);field(dl,'Bookmark ID',id);
  box.append(dl,el('p','A bookmark stores a link. Save HTML, PDF or PNG to preserve the page contents. Later captures reflect the page at capture time.','muted'),bookmarkTools(b));
  const copies=bookmarkCaptures(id);box.append(el('h3',`Saved copies (${copies.length})`));
  for(const c of copies)box.append(button(c.evidence_number+' · '+c.capture_request+' · '+localTime(c.times.capture_started_at),()=>showCapture(c.capture_id),true));
  box.append(button('Delete bookmark',async()=>{if(busy || bookmarkOperation)throw new Error('Wait for the current operation.');await canWrite();const c=context();if(c.caseId!==b.case_id)throw new Error('Open the bookmark’s original case first.');await exclusive(async()=>{const fresh=await loadState(c.root,c.workspace,c.caseId),record=fresh.bookmarks[id];if(!record || record.deleted)return;await append(c.root,c.workspace,c.caseId,'bookmark_deleted','bookmarks',{...record,deleted:true});});$('details').hidden=true;status('Bookmark removed. Saved evidence files are preserved.');await refresh({annotations:false});}));
}
action('bookmark-page',async()=>{
  if(bookmarkOperation || busy)return;bookmarkOperation=true;busy=true;updateSetup();
  try{const source=await currentTab();assertWebTab(source);await canWrite();const c=context(),record=await exclusive(()=>saveBookmark(c.root,c.workspace,c.caseId,source));await refresh({annotations:false});switchView('bookmarks');showBookmark(record.bookmark_id);status('Bookmark saved on disk. Page contents have not been captured.');}
  finally{bookmarkOperation=false;busy=false;updateSetup();}
});
async function captureBookmark(bookmark,kind){
  if(bookmarkOperation || busy)throw new Error('Wait for the current operation.');bookmarkOperation=true;busy=true;updateSetup();
  try{
    await canWrite();const c=context();if(c.caseId!==bookmark.case_id)throw new Error('Open the bookmark’s original case first.');
    status('Opening bookmark. Waiting for the page to load…');
    const window=await chrome.windows.getCurrent(),tabs=await chrome.tabs.query({windowId:window.id}),existing=tabs.find(t=>t.active && t.url===bookmark.source_url) || tabs.find(t=>t.url===bookmark.source_url),opened=existing?await chrome.tabs.update(existing.id,{active:true}):await chrome.tabs.create({windowId:window.id,url:bookmark.source_url,active:true}),deadline=performance.now()+30000;
    let source;
    while(performance.now()<deadline){source=await chrome.tabs.get(opened.id);if(source.status==='complete')break;await new Promise(resolve=>setTimeout(resolve,100));}
    if(source?.status!=='complete')throw new Error('Page did not finish loading within 30 seconds. The bookmark is intact. Open it and try again.');
    assertWebTab(source,preferences);if(c.root!==root || c.caseId!==activeCase)throw new Error('The active case changed. Try again in the original case.');
    busy=false;
    await runCapture(kind,{tabId:source.id,caseId:c.caseId,sourceUrl:source.url,bookmarkId:bookmark.bookmark_id});
  }finally{bookmarkOperation=false;busy=false;updateSetup();renderList();}
}
